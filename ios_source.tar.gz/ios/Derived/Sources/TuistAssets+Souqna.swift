// swiftlint:disable:this file_name
// swiftlint:disable all
// swift-format-ignore-file
// swiftformat:disable all
// Generated using tuist — https://github.com/tuist/tuist



#if os(macOS)
#if hasFeature(InternalImportsByDefault)
public import AppKit
#else
import AppKit
#endif
#else
#if hasFeature(InternalImportsByDefault)
public import UIKit
#else
import UIKit
#endif
#endif

#if canImport(SwiftUI)
#if hasFeature(InternalImportsByDefault)
public import SwiftUI
#else
import SwiftUI
#endif
#endif

// MARK: - Asset Catalogs

public enum SouqnaAsset: Sendable {
  public enum Assets {
  public static let accentColor = SouqnaColors(name: "AccentColor")
    public static let activityIndicatorColor = SouqnaColors(name: "activityIndicatorColor")
    public static let inactiveTabBarItemColor = SouqnaColors(name: "inactiveTabBarItemColor")
    public static let navigationBarTintColor = SouqnaColors(name: "navigationBarTintColor")
    public static let sidebarBackgroundColor = SouqnaColors(name: "sidebarBackgroundColor")
    public static let sidebarTextColor = SouqnaColors(name: "sidebarTextColor")
    public static let statusBarBackgroundColor = SouqnaColors(name: "statusBarBackgroundColor")
    public static let tabBarTintColor = SouqnaColors(name: "tabBarTintColor")
    public static let tintColor = SouqnaColors(name: "tintColor")
    public static let titleColor = SouqnaColors(name: "titleColor")
  }
  public enum Images {
  public static let headerImage = SouqnaImages(name: "HeaderImage")
    public static let launchBackground = SouqnaImages(name: "LaunchBackground")
    public static let launchCenter = SouqnaImages(name: "LaunchCenter")
    public static let navBarImage = SouqnaImages(name: "NavBarImage")
    public static let chevronDown = SouqnaImages(name: "chevronDown")
    public static let chevronUp = SouqnaImages(name: "chevronUp")
    public static let gear = SouqnaImages(name: "gear")
    public static let leftImage = SouqnaImages(name: "leftImage")
    public static let navImage = SouqnaImages(name: "navImage")
    public static let rightImage = SouqnaImages(name: "rightImage")
  }
}

// MARK: - Implementation Details

public final class SouqnaColors: Sendable {
  public let name: String

  #if os(macOS)
  public typealias Color = NSColor
  #elseif os(iOS) || os(tvOS) || os(watchOS) || os(visionOS)
  public typealias Color = UIColor
  #endif

  @available(iOS 11.0, tvOS 11.0, watchOS 4.0, macOS 10.13, visionOS 1.0, *)
  public var color: Color {
    guard let color = Color(asset: self) else {
      fatalError("Unable to load color asset named \(name).")
    }
    return color
  }

  #if canImport(SwiftUI)
  @available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
  public var swiftUIColor: SwiftUI.Color {
      return SwiftUI.Color(asset: self)
  }
  #endif

  fileprivate init(name: String) {
    self.name = name
  }
}

public extension SouqnaColors.Color {
  @available(iOS 11.0, tvOS 11.0, watchOS 4.0, macOS 10.13, visionOS 1.0, *)
  convenience init?(asset: SouqnaColors) {
    let bundle = Bundle.module
    #if os(iOS) || os(tvOS) || os(visionOS)
    self.init(named: asset.name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    self.init(named: NSColor.Name(asset.name), bundle: bundle)
    #elseif os(watchOS)
    self.init(named: asset.name)
    #endif
  }
}

#if canImport(SwiftUI)
@available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
public extension SwiftUI.Color {
  init(asset: SouqnaColors) {
    let bundle = Bundle.module
    self.init(asset.name, bundle: bundle)
  }
}
#endif

public struct SouqnaImages: Sendable {
  public let name: String

  #if os(macOS)
  public typealias Image = NSImage
  #elseif os(iOS) || os(tvOS) || os(watchOS) || os(visionOS)
  public typealias Image = UIImage
  #endif

  public var image: Image {
    let bundle = Bundle.module
    #if os(iOS) || os(tvOS) || os(visionOS)
    let image = Image(named: name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    let image = bundle.image(forResource: NSImage.Name(name))
    #elseif os(watchOS)
    let image = Image(named: name)
    #endif
    guard let result = image else {
      fatalError("Unable to load image asset named \(name).")
    }
    return result
  }

  #if canImport(SwiftUI)
  @available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
  public var swiftUIImage: SwiftUI.Image {
    SwiftUI.Image(asset: self)
  }
  #endif
}

#if canImport(SwiftUI)
@available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
public extension SwiftUI.Image {
  init(asset: SouqnaImages) {
    let bundle = Bundle.module
    self.init(asset.name, bundle: bundle)
  }

  init(asset: SouqnaImages, label: Text) {
    let bundle = Bundle.module
    self.init(asset.name, bundle: bundle, label: label)
  }

  init(decorative asset: SouqnaImages) {
    let bundle = Bundle.module
    self.init(decorative: asset.name, bundle: bundle)
  }
}
#endif

// swiftformat:enable all
// swiftlint:enable all
